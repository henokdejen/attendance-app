import EndPoints from './API'

// this is how we use it in the react project.
EndPoints.profile.getMy().then(data => console.log(data))
